

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class ="card-header">
        <h4>Ediy/UpdateEvent</h4>
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('update-event/'.$event->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">

            <div class ="col-md-6 mb-3">
            <label for="">Event Name</label>
            <input type="text" value="<?php echo e($event-> event_name); ?>" class="form-control" name="event_name">
            </div>

            <div class="col-md-12 mb-3">
            <label for="">Description</label>
            <textarea name="description"rows="3"class="form-control"><?php echo e($event->description); ?></textarea>
            </div>

            <div class="col-md-12 mb-3">
            <label for="">Committee Requirement</label>
            <textarea name="committee_requirement"rows="3"class="form-control"><?php echo e($event->committee_requirement); ?></textarea>
            </div>

            <div class ="col-md-6 mb-3">
            <label for="">Date</label>
            <input type="date" value="<?php echo e($event-> date); ?>" name="date">   
            </div>
            <?php if($event->image): ?>
            <img src="<?php echo e(asset('assets/uploads/event/'.$event->image)); ?>" alt="Event image">
            <?php endif; ?>
            <div class="col-md-12 mb-3">
                <input type="file" name="image">
            </div>

            <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Submit</button>



    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\EaktiV\resources\views/admin/events/edit.blade.php ENDPATH**/ ?>
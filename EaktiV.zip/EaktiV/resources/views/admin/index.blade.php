@extends('layouts.admin')

@section('content')
<div class="card">
    <div class="card-body">
        <h1>Aisyah</h1>
    </div>
</div>
    
@endsection